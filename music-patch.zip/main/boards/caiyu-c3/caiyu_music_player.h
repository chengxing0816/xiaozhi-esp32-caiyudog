#ifndef CAIYU_MUSIC_PLAYER_H
#define CAIYU_MUSIC_PLAYER_H

#include <atomic>
#include <functional>
#include <mutex>
#include <string>

/*
 * 局域网音乐播放器：从 http:// 直链拉 Ogg/Opus 流，解封装后塞进现有的
 * 「解码队列 -> 播放队列」通路，和 TTS 走完全相同的出声路径。
 *
 * 设计取舍：
 * 1. 只支持 http，不支持 https。C3 没有 PSRAM，TLS 每条记录都要现分配
 *    16KB 接收缓冲，而 OggDemuxer 的包缓冲只有 4KB，两者抢堆必翻车。
 * 2. 用 lwIP 原生 socket 自己发 HTTP GET，不链接 esp_http_client。
 *    esp_http_client 会把 esp-tls + mbedtls 一起拉进来，C3 的 DRAM 只有
 *    400KB，那几 KB 的静态占用就足以让 LVGL 初始化时分配失败、屏幕黑掉。
 * 3. 采样率跟随文件头（推荐 24000），不强改。本板 codec 输出就是 24000，
 *    正好不用重采样；给 16000 的文件也能播，由 AudioService 自己建转换器。
 * 4. 播放期间关掉唤醒词，本板没有 AEC，喇叭的声音会被麦克风收进去。
 * 5. 读流、解封装、推包都在独立任务里（栈 6KB），不占 httpd 的 4KB 栈。
 */
class CaiyuMusicPlayer {
public:
    // playing: 是否正在播放；title: 当前曲目名；error: 0 表示正常结束/无错
    using StateCallback = std::function<void(bool playing, const std::string& title, const char* error)>;

    static CaiyuMusicPlayer& GetInstance();

    // 返回 false 表示参数不合法或上一次还没收尾，error 给出原因（可为 nullptr）
    bool Start(const std::string& url, const char** error);
    void Stop();

    bool playing() const { return playing_.load(); }
    std::string title() const;
    int volume() const { return volume_.load(); }
    void SetVolume(int volume);

    void SetStateCallback(StateCallback callback);

private:
    CaiyuMusicPlayer() = default;
    ~CaiyuMusicPlayer() = default;
    CaiyuMusicPlayer(const CaiyuMusicPlayer&) = delete;
    CaiyuMusicPlayer& operator=(const CaiyuMusicPlayer&) = delete;

    static void TaskEntry(void* arg);
    void Run();
    void Notify(bool playing, const char* error);

    std::atomic<bool> playing_{false};
    std::atomic<bool> stop_requested_{false};
    std::atomic<bool> task_running_{false};
    std::atomic<int> volume_{70};

    std::string url_;
    std::string title_;
    mutable std::mutex mutex_;
    std::mutex client_mutex_;
    int sock_ = -1;

    StateCallback callback_;
};

#endif
