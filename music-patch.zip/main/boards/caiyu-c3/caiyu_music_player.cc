#include "caiyu_music_player.h"

#include <esp_log.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include <cstdio>
#include <cstring>
#include <memory>
#include <new>

#include "application.h"
#include "audio_codec.h"
#include "audio_service.h"
#include "board.h"
#include "ogg_demuxer.h"
#include "protocol.h"

namespace {

const char* TAG = "CaiyuMusic";

constexpr size_t kReadChunk = 2048;      // 每次从 socket 读的字节数
constexpr int kTaskStack = 7168;         // esp_http_client + 解封装，7KB 才踏实
constexpr int kTaskPriority = 3;
constexpr size_t kMaxUrlLen = 240;
constexpr int64_t kDrainTimeoutUs = 60LL * 1000 * 1000;   // 播完最多等 60 秒排空
constexpr int kSwitchWaitMs = 800;       // 换歌时等上一首收尾的上限

// URL 里的 %XX 还原成可读字符，主要是为了中文歌名能在网页上正常显示
std::string PercentDecode(const std::string& in) {
    std::string out;
    out.reserve(in.size());
    for (size_t i = 0; i < in.size(); ++i) {
        if (in[i] == '%' && i + 2 < in.size()) {
            auto hex = [](char c) -> int {
                if (c >= '0' && c <= '9') return c - '0';
                if (c >= 'a' && c <= 'f') return c - 'a' + 10;
                if (c >= 'A' && c <= 'F') return c - 'A' + 10;
                return -1;
            };
            int hi = hex(in[i + 1]);
            int lo = hex(in[i + 2]);
            if (hi >= 0 && lo >= 0) {
                out.push_back(static_cast<char>((hi << 4) | lo));
                i += 2;
                continue;
            }
        }
        out.push_back(in[i]);
    }
    return out;
}

std::string MakeTitle(const std::string& url) {
    size_t slash = url.find_last_of('/');
    std::string name = (slash == std::string::npos) ? url : url.substr(slash + 1);
    size_t query = name.find('?');
    if (query != std::string::npos) {
        name = name.substr(0, query);
    }
    size_t dot = name.find_last_of('.');
    if (dot != std::string::npos && dot > 0) {
        name = name.substr(0, dot);
    }
    name = PercentDecode(name);
    if (name.empty()) {
        name = "音乐";
    }
    return name;
}

}  // namespace

CaiyuMusicPlayer& CaiyuMusicPlayer::GetInstance() {
    static CaiyuMusicPlayer instance;
    return instance;
}

std::string CaiyuMusicPlayer::title() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return title_;
}

void CaiyuMusicPlayer::SetStateCallback(StateCallback callback) {
    std::lock_guard<std::mutex> lock(mutex_);
    callback_ = std::move(callback);
}

void CaiyuMusicPlayer::Notify(bool playing, const char* error) {
    StateCallback callback;
    std::string title_copy;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        callback = callback_;
        title_copy = title_;
    }
    if (callback) {
        callback(playing, title_copy, error);
    }
}

void CaiyuMusicPlayer::SetVolume(int volume) {
    if (volume < 0) volume = 0;
    if (volume > 100) volume = 100;
    volume_ = volume;
    auto* codec = Board::GetInstance().GetAudioCodec();
    if (codec != nullptr) {
        codec->SetOutputVolume(volume);
    }
}

bool CaiyuMusicPlayer::Start(const std::string& url, const char** error) {
    auto fail = [error](const char* message) {
        if (error != nullptr) {
            *error = message;
        }
        return false;
    };

    if (url.rfind("http://", 0) != 0) {
        return fail("地址要以 http:// 开头，设备不支持 https");
    }
    if (url.size() > kMaxUrlLen) {
        return fail("地址太长");
    }
    if (url.find(' ') != std::string::npos) {
        return fail("地址里不能有空格");
    }

    // 换歌：先把上一首收干净，否则两路流会抢解码队列
    if (task_running_.load()) {
        Stop();
        for (int waited = 0; waited < kSwitchWaitMs && task_running_.load(); waited += 20) {
            vTaskDelay(pdMS_TO_TICKS(20));
        }
        if (task_running_.load()) {
            return fail("上一首还在收，等两秒再点");
        }
    }

    {
        std::lock_guard<std::mutex> lock(mutex_);
        url_ = url;
        title_ = MakeTitle(url);
    }

    stop_requested_ = false;
    playing_ = true;
    task_running_ = true;

    if (xTaskCreate(&CaiyuMusicPlayer::TaskEntry, "caiyu_music", kTaskStack, this,
                    kTaskPriority, nullptr) != pdPASS) {
        playing_ = false;
        task_running_ = false;
        return fail("创建播放任务失败，内存不足");
    }

    ESP_LOGI(TAG, "start: %s", url.c_str());
    Notify(true, nullptr);
    return true;
}

void CaiyuMusicPlayer::Stop() {
    if (!playing_.load()) {
        return;
    }
    stop_requested_ = true;

    {
        // 持锁 close：防止任务此刻正好在 cleanup，拿到的指针已经失效
        std::lock_guard<std::mutex> lock(client_mutex_);
        if (client_ != nullptr) {
            // 让阻塞在 esp_http_client_read 的任务立刻返回
            esp_http_client_close(client_);
        }
    }

    // 清空解码/播放队列，同时唤醒可能卡在 PushPacketToDecodeQueue 的任务
    Application::GetInstance().GetAudioService().ResetDecoder();
    ESP_LOGI(TAG, "stop requested");
    // 广播走 httpd_queue_work 排队，不会和当前的 WebSocket 帧抢 socket
    Notify(false, nullptr);
}

void CaiyuMusicPlayer::TaskEntry(void* arg) {
    auto* self = static_cast<CaiyuMusicPlayer*>(arg);
    self->Run();
    vTaskDelete(nullptr);
}

void CaiyuMusicPlayer::Run() {
    auto& app = Application::GetInstance();
    auto& audio = app.GetAudioService();
    auto* codec = Board::GetInstance().GetAudioCodec();

    if (codec != nullptr) {
        codec->SetOutputVolume(volume_.load());
    }

    // 先把残留的 TTS 尾巴清掉，再关唤醒词：本板没有 AEC，喇叭一响就会喂给自己的麦克风
    audio.ResetDecoder();
    audio.EnableWakeWordDetection(false);

    const char* error = nullptr;
    bool finished = false;
    size_t packets = 0;

    esp_http_client_config_t config = {};
    config.url = url_.c_str();
    config.timeout_ms = 8000;
    config.buffer_size = 1024;
    config.buffer_size_tx = 512;
    config.keep_alive_enable = false;
    config.disable_auto_redirect = true;

    esp_http_client_handle_t client = nullptr;
    std::unique_ptr<uint8_t[]> buffer;
    std::unique_ptr<OggDemuxer> demuxer;

    do {
        client = esp_http_client_init(&config);
        if (client == nullptr) {
            error = "内存不足，建不了连接";
            break;
        }
        {
            std::lock_guard<std::mutex> lock(client_mutex_);
            client_ = client;
        }
        if (stop_requested_.load()) {
            break;
        }

        esp_err_t err = esp_http_client_open(client, 0);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "open failed: %s", esp_err_to_name(err));
            error = "打不开这个音频地址";
            break;
        }

        int64_t content_length = esp_http_client_fetch_headers(client);
        if (content_length < 0) {
            error = "服务器没有返回数据";
            break;
        }
        ESP_LOGI(TAG, "connected, content length: %lld", static_cast<long long>(content_length));
        if (stop_requested_.load()) {
            break;
        }

        demuxer = std::make_unique<OggDemuxer>();
        demuxer->OnDemuxerFinished([&audio, &packets](const uint8_t* data, int sample_rate, size_t size) {
            if (size == 0) {
                return;
            }
            auto packet = std::make_unique<AudioStreamPacket>();
            packet->sample_rate = (sample_rate > 0) ? sample_rate : 24000;
            packet->frame_duration = 60;
            packet->payload.resize(size);
            std::memcpy(packet->payload.data(), data, size);
            // wait = true：队列满（40 包 ≈ 2.4 秒）就阻塞，天然形成限速，不会把内存吃光
            if (audio.PushPacketToDecodeQueue(std::move(packet), true)) {
                ++packets;
            }
        });
        demuxer->Reset();

        buffer.reset(new (std::nothrow) uint8_t[kReadChunk]);
        if (!buffer) {
            error = "内存不足";
            break;
        }

        finished = true;
        while (!stop_requested_.load()) {
            int read = esp_http_client_read(client, reinterpret_cast<char*>(buffer.get()),
                                            static_cast<int>(kReadChunk));
            if (read < 0) {
                ESP_LOGW(TAG, "read failed: %d", read);
                error = "网络中断";
                finished = false;
                break;
            }
            if (read == 0) {
                break;  // 文件读完
            }
            demuxer->Process(buffer.get(), static_cast<size_t>(read));
        }
    } while (false);

    if (finished && packets == 0) {
        // 一个包都没拆出来，多半是把 mp3 当 ogg 了
        error = "这不是 Ogg/Opus 文件，先用 ffmpeg 转一下";
        finished = false;
    }

    // 等最后一帧真正播完再收摊，否则停在这里会把尾巴掐掉
    if (finished && !stop_requested_.load()) {
        const int64_t deadline = esp_timer_get_time() + kDrainTimeoutUs;
        while (!stop_requested_.load() && !audio.IsPlaybackIdle() &&
               esp_timer_get_time() < deadline) {
            vTaskDelay(pdMS_TO_TICKS(50));
        }
    }

    {
        std::lock_guard<std::mutex> lock(client_mutex_);
        if (client_ != nullptr) {
            esp_http_client_close(client_);
            esp_http_client_cleanup(client_);
            client_ = nullptr;
        }
    }

    buffer.reset();
    demuxer.reset();

    audio.ResetDecoder();
    // 只有在设备空闲时才恢复唤醒词；正在对话/配网就别抢它的麦克风
    if (app.GetDeviceState() == kDeviceStateIdle) {
        audio.EnableWakeWordDetection(true);
    }

    playing_ = false;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        task_running_ = false;
    }

    if (error != nullptr) {
        ESP_LOGW(TAG, "finished with error: %s", error);
    } else {
        ESP_LOGI(TAG, "finished");
    }
    Notify(false, error);
}
