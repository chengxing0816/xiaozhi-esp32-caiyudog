#include "caiyu_music_player.h"

#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

#include <esp_log.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <new>

#include "application.h"
#include "audio_codec.h"
#include "audio_service.h"
#include "board.h"
#include "ogg_demuxer.h"
#include "protocol.h"

namespace {

const char* TAG = "CaiyuMusic";

constexpr size_t kReadChunk = 2048;      // 每次从 socket 读的字节数
constexpr size_t kHeaderBuf = 2048;      // 响应头 + 紧跟的一段 body（http.server 的头不到 300 字节）
constexpr int kTaskStack = 7168;         // socket + 解封装，7KB 才踏实
constexpr int kTaskPriority = 3;
constexpr size_t kMaxUrlLen = 240;
constexpr int kConnectTimeoutMs = 8000;
constexpr int64_t kDrainTimeoutUs = 60LL * 1000 * 1000;   // 播完最多等 60 秒排空
constexpr int kSwitchWaitMs = 800;       // 换歌时等上一首收尾的上限

// URL 里的 %XX 还原成可读字符，主要是为了中文歌名能在网页上正常显示
std::string PercentDecode(const std::string& in) {
    std::string out;
    out.reserve(in.size());
    for (size_t i = 0; i < in.size(); ++i) {
        if (in[i] == '%' && i + 2 < in.size()) {
            auto hex = [](char c) -> int {
                if (c >= '0' && c <= '9') return c - '0';
                if (c >= 'a' && c <= 'f') return c - 'a' + 10;
                if (c >= 'A' && c <= 'F') return c - 'A' + 10;
                return -1;
            };
            int hi = hex(in[i + 1]);
            int lo = hex(in[i + 2]);
            if (hi >= 0 && lo >= 0) {
                out.push_back(static_cast<char>((hi << 4) | lo));
                i += 2;
                continue;
            }
        }
        out.push_back(in[i]);
    }
    return out;
}

std::string MakeTitle(const std::string& url) {
    size_t slash = url.find_last_of('/');
    std::string name = (slash == std::string::npos) ? url : url.substr(slash + 1);
    size_t query = name.find('?');
    if (query != std::string::npos) {
        name = name.substr(0, query);
    }
    size_t dot = name.find_last_of('.');
    if (dot != std::string::npos && dot > 0) {
        name = name.substr(0, dot);
    }
    name = PercentDecode(name);
    if (name.empty()) {
        name = "音乐";
    }
    return name;
}

struct UrlParts {
    std::string host;
    int port;
    std::string path;
};

// 只认 http://host[:port]/path，不认 https
bool ParseUrl(const std::string& url, UrlParts* out) {
    static const char* kPrefix = "http://";
    constexpr size_t kPrefixLen = 7;
    if (url.rfind(kPrefix, 0) != 0) {
        return false;
    }
    std::string rest = url.substr(kPrefixLen);
    if (rest.empty()) {
        return false;
    }
    size_t slash = rest.find('/');
    std::string hostport = (slash == std::string::npos) ? rest : rest.substr(0, slash);
    out->path = (slash == std::string::npos) ? "/" : rest.substr(slash);
    if (out->path.empty()) {
        out->path = "/";
    }
    out->port = 80;
    size_t colon = hostport.rfind(':');
    if (colon != std::string::npos) {
        int parsed = std::atoi(hostport.c_str() + colon + 1);
        if (parsed > 0 && parsed < 65536) {
            out->port = parsed;
        }
        hostport = hostport.substr(0, colon);
    }
    out->host = hostport;
    return !out->host.empty();
}

int ConnectHttp(const UrlParts& target) {
    struct addrinfo hints;
    std::memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    char port_text[8];
    std::snprintf(port_text, sizeof(port_text), "%d", target.port);

    struct addrinfo* result = nullptr;
    if (getaddrinfo(target.host.c_str(), port_text, &hints, &result) != 0 || result == nullptr) {
        ESP_LOGE(TAG, "resolve failed: %s", target.host.c_str());
        return -1;
    }

    int fd = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (fd < 0) {
        freeaddrinfo(result);
        return -1;
    }

    struct timeval tv;
    tv.tv_sec = kConnectTimeoutMs / 1000;
    tv.tv_usec = (kConnectTimeoutMs % 1000) * 1000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    if (connect(fd, result->ai_addr, result->ai_addrlen) != 0) {
        ESP_LOGE(TAG, "connect failed: errno %d", errno);
        close(fd);
        freeaddrinfo(result);
        return -1;
    }
    freeaddrinfo(result);
    return fd;
}

bool SendGet(int fd, const UrlParts& target) {
    char request[512];
    int length = std::snprintf(request, sizeof(request),
                                "GET %s HTTP/1.0\r\n"
                                "Host: %s\r\n"
                                "User-Agent: caiyu-dog/1.0\r\n"
                                "Accept: */*\r\n"
                                "Connection: close\r\n"
                                "\r\n",
                                target.path.c_str(), target.host.c_str());
    if (length <= 0 || static_cast<size_t>(length) >= sizeof(request)) {
        return false;
    }
    int sent = 0;
    while (sent < length) {
        int written = send(fd, request + sent, length - sent, 0);
        if (written <= 0) {
            return false;
        }
        sent += written;
    }
    return true;
}

// 读掉响应头，把紧跟其后的那段 body 挪到 buf 开头。
// 成功返回 true 并给出 body 前缀长度；失败时 *error 指向原因。
bool ReadHeaders(int fd, uint8_t* buf, size_t cap, size_t* body_len, const char** error) {
    size_t used = 0;
    while (used + 1 < cap) {
        int read = recv(fd, buf + used, cap - 1 - used, 0);
        if (read < 0) {
            *error = "网络中断";
            return false;
        }
        if (read == 0) {
            *error = "服务器没有返回数据";
            return false;
        }
        used += static_cast<size_t>(read);
        buf[used] = '\0';

        char* header_end = strstr(reinterpret_cast<char*>(buf), "\r\n\r\n");
        if (header_end == nullptr) {
            continue;
        }
        if (std::strncmp(reinterpret_cast<char*>(buf), "HTTP/", 5) != 0) {
            *error = "返回的不是 HTTP 响应";
            return false;
        }
        char* space = std::strchr(reinterpret_cast<char*>(buf), ' ');
        if (space == nullptr || std::strncmp(space + 1, "200", 3) != 0) {
            *error = "服务器返回错误，文件可能不在";
            return false;
        }
        size_t header_len = static_cast<size_t>(header_end - reinterpret_cast<char*>(buf)) + 4;
        *body_len = used - header_len;
        if (*body_len > 0) {
            std::memmove(buf, buf + header_len, *body_len);
        }
        return true;
    }
    *error = "响应头太长";
    return false;
}

}  // namespace

CaiyuMusicPlayer& CaiyuMusicPlayer::GetInstance() {
    static CaiyuMusicPlayer instance;
    return instance;
}

std::string CaiyuMusicPlayer::title() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return title_;
}

void CaiyuMusicPlayer::SetStateCallback(StateCallback callback) {
    std::lock_guard<std::mutex> lock(mutex_);
    callback_ = std::move(callback);
}

void CaiyuMusicPlayer::Notify(bool playing, const char* error) {
    StateCallback callback;
    std::string title_copy;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        callback = callback_;
        title_copy = title_;
    }
    if (callback) {
        callback(playing, title_copy, error);
    }
}

void CaiyuMusicPlayer::SetVolume(int volume) {
    if (volume < 0) volume = 0;
    if (volume > 100) volume = 100;
    volume_ = volume;
    auto* codec = Board::GetInstance().GetAudioCodec();
    if (codec != nullptr) {
        codec->SetOutputVolume(volume);
    }
}

bool CaiyuMusicPlayer::Start(const std::string& url, const char** error) {
    auto fail = [error](const char* message) {
        if (error != nullptr) {
            *error = message;
        }
        return false;
    };

    UrlParts target;
    if (!ParseUrl(url, &target)) {
        return fail("地址要以 http:// 开头，设备不支持 https");
    }
    if (url.size() > kMaxUrlLen) {
        return fail("地址太长");
    }
    if (url.find(' ') != std::string::npos) {
        return fail("地址里不能有空格");
    }

    // 换歌：先把上一首收干净，否则两路流会抢解码队列
    if (task_running_.load()) {
        Stop();
        for (int waited = 0; waited < kSwitchWaitMs && task_running_.load(); waited += 20) {
            vTaskDelay(pdMS_TO_TICKS(20));
        }
        if (task_running_.load()) {
            return fail("上一首还在收，等两秒再点");
        }
    }

    {
        std::lock_guard<std::mutex> lock(mutex_);
        url_ = url;
        title_ = MakeTitle(url);
    }

    stop_requested_ = false;
    playing_ = true;
    task_running_ = true;

    if (xTaskCreate(&CaiyuMusicPlayer::TaskEntry, "caiyu_music", kTaskStack, this,
                    kTaskPriority, nullptr) != pdPASS) {
        playing_ = false;
        task_running_ = false;
        return fail("创建播放任务失败，内存不足");
    }

    ESP_LOGI(TAG, "start: %s", url.c_str());
    Notify(true, nullptr);
    return true;
}

void CaiyuMusicPlayer::Stop() {
    if (!playing_.load()) {
        return;
    }
    stop_requested_ = true;

    {
        // 持锁 shutdown：让阻塞在 recv 的任务立刻返回。真正的 close 交给任务自己收尾，
        // 这里只关读写方向，避免 double close。
        std::lock_guard<std::mutex> lock(client_mutex_);
        if (sock_ >= 0) {
            shutdown(sock_, SHUT_RDWR);
        }
    }

    // 清空解码/播放队列，同时唤醒可能卡在 PushPacketToDecodeQueue 的任务
    Application::GetInstance().GetAudioService().ResetDecoder();
    ESP_LOGI(TAG, "stop requested");
    // 广播走 httpd_queue_work 排队，不会和当前的 WebSocket 帧抢 socket
    Notify(false, nullptr);
}

void CaiyuMusicPlayer::TaskEntry(void* arg) {
    auto* self = static_cast<CaiyuMusicPlayer*>(arg);
    self->Run();
    vTaskDelete(nullptr);
}

void CaiyuMusicPlayer::Run() {
    auto& app = Application::GetInstance();
    auto& audio = app.GetAudioService();
    auto* codec = Board::GetInstance().GetAudioCodec();

    if (codec != nullptr) {
        codec->SetOutputVolume(volume_.load());
    }

    // 先把残留的 TTS 尾巴清掉，再关唤醒词：本板没有 AEC，喇叭一响就会喂给自己的麦克风
    audio.ResetDecoder();
    audio.EnableWakeWordDetection(false);

    const char* error = nullptr;
    bool finished = false;
    size_t packets = 0;

    UrlParts target;
    if (!ParseUrl(url_, &target)) {
        error = "地址格式不对";
    }

    std::unique_ptr<uint8_t[]> buffer;
    std::unique_ptr<OggDemuxer> demuxer;
    int fd = -1;

    if (error == nullptr) {
        fd = ConnectHttp(target);
        if (fd < 0) {
            error = "打不开这个音频地址";
        } else {
            std::lock_guard<std::mutex> lock(client_mutex_);
            sock_ = fd;
        }
    }

    do {
        if (error != nullptr || stop_requested_.load()) {
            break;
        }
        if (!SendGet(fd, target)) {
            error = "发请求失败";
            break;
        }

        buffer.reset(new (std::nothrow) uint8_t[kHeaderBuf]);
        if (!buffer) {
            error = "内存不足";
            break;
        }

        size_t body_len = 0;
        if (!ReadHeaders(fd, buffer.get(), kHeaderBuf, &body_len, &error)) {
            break;
        }
        ESP_LOGI(TAG, "connected, first body chunk: %u bytes", static_cast<unsigned>(body_len));
        if (stop_requested_.load()) {
            break;
        }

        demuxer = std::make_unique<OggDemuxer>();
        demuxer->OnDemuxerFinished([&audio, &packets](const uint8_t* data, int sample_rate, size_t size) {
            if (size == 0) {
                return;
            }
            auto packet = std::make_unique<AudioStreamPacket>();
            packet->sample_rate = (sample_rate > 0) ? sample_rate : 24000;
            packet->frame_duration = 60;
            packet->payload.resize(size);
            std::memcpy(packet->payload.data(), data, size);
            // wait = true：队列满（40 包 ≈ 2.4 秒）就阻塞，天然形成限速，不会把内存吃光
            if (audio.PushPacketToDecodeQueue(std::move(packet), true)) {
                ++packets;
            }
        });
        demuxer->Reset();

        finished = true;
        if (body_len > 0) {
            demuxer->Process(buffer.get(), body_len);
        }

        while (!stop_requested_.load()) {
            int read = recv(fd, buffer.get(), kReadChunk, 0);
            if (read < 0) {
                // shutdown 会让 recv 直接失败，这是主动停止，不算错误
                if (!stop_requested_.load()) {
                    ESP_LOGW(TAG, "read failed: errno %d", errno);
                    error = "网络中断";
                    finished = false;
                }
                break;
            }
            if (read == 0) {
                break;  // 文件读完
            }
            demuxer->Process(buffer.get(), static_cast<size_t>(read));
        }
    } while (false);

    if (finished && packets == 0) {
        // 一个包都没拆出来，多半是把 mp3 当 ogg 了
        error = "这不是 Ogg/Opus 文件，先用 ffmpeg 转一下";
        finished = false;
    }

    // 等最后一帧真正播完再收摊，否则停在这里会把尾巴掐掉
    if (finished && !stop_requested_.load()) {
        const int64_t deadline = esp_timer_get_time() + kDrainTimeoutUs;
        while (!stop_requested_.load() && !audio.IsPlaybackIdle() &&
               esp_timer_get_time() < deadline) {
            vTaskDelay(pdMS_TO_TICKS(50));
        }
    }

    {
        std::lock_guard<std::mutex> lock(client_mutex_);
        if (sock_ >= 0) {
            close(sock_);
            sock_ = -1;
        }
    }

    buffer.reset();
    demuxer.reset();

    audio.ResetDecoder();
    // 只有在设备空闲时才恢复唤醒词；正在对话/配网就别抢它的麦克风
    if (app.GetDeviceState() == kDeviceStateIdle) {
        audio.EnableWakeWordDetection(true);
    }

    playing_ = false;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        task_running_ = false;
    }

    if (error != nullptr) {
        ESP_LOGW(TAG, "finished with error: %s", error);
    } else {
        ESP_LOGI(TAG, "finished");
    }
    Notify(false, error);
}
